import Approutes from "./Routes/Approutes";
import { Toaster } from "react-hot-toast";

function App() {
  
  return (
    <>
      <Approutes />
      <Toaster />

    </>
  );
}

export default App;
