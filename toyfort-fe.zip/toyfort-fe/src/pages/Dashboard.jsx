import React from 'react'

function Dashboard() {
  return (
    <h1 >toyfort dashboard</h1>
  )
}

export default Dashboard